/**
 * PayMeSafe — полный сервер платформы. ZERO DEPENDENCIES.
 *
 * Запуск:  node server.js      → http://localhost:3001
 * Никакого npm install: только встроенные модули Node 18+.
 *
 * Что внутри:
 *   - Статика (index.html)
 *   - Auth: пароли через scrypt, токены через HMAC (без сторонних JWT-библиотек)
 *   - Движок эскроу (машина состояний + леджер) — escrow-engine/core
 *   - Чат сделки и арбитраж со сплит-решениями
 *   - DEV-режим: симуляция депозита вместо Tron watcher'а,
 *     чтобы полный цикл можно было пройти без testnet.
 *     В production депозиты подтверждает ТОЛЬКО deposit-watcher из блокчейна.
 */

const http = require('http');
const fs = require('fs');
const path = require('path');
const crypto = require('crypto');

const { EscrowEngine } = require('./escrow-engine/core/escrow-engine');
const { DealChat } = require('./escrow-engine/core/chat');
const { ArbitrationService } = require('./escrow-engine/core/arbitration');
const { fromBaseUnits, toBaseUnits } = require('./escrow-engine/core/fees');

const PORT = process.env.PORT || 3001;
const DEV_MODE = process.env.DEV_MODE !== '0'; // по умолчанию включён

/**
 * Кошелёк платформы для пополнений (Tron, TRC-20 USDT).
 * ⚠️ Единый адрес на все сделки: в production сопоставление депозита со
 * сделкой должно идти по уникальной сумме (amount + случайные центы) или
 * по уникальным адресам на сделку (см. escrow-engine/tron/tron-wallet.js).
 * Приватный ключ этого адреса живёт ТОЛЬКО в env на сервере выплат.
 */
const PLATFORM_DEPOSIT_ADDRESS = process.env.PLATFORM_DEPOSIT_ADDRESS || 'TYyr8571CtVU1PyQ7Lam5uoJh73WCMC7Pr';
const DATA_DIR = path.join(__dirname, 'data');
fs.mkdirSync(DATA_DIR, { recursive: true });

// ─────────────────────────── СЕКРЕТ И ПОЛЬЗОВАТЕЛИ ───────────────────────────

const secretFile = path.join(DATA_DIR, 'secret');
if (!fs.existsSync(secretFile)) fs.writeFileSync(secretFile, crypto.randomBytes(32).toString('hex'));
const SECRET = fs.readFileSync(secretFile, 'utf8');

const usersFile = path.join(DATA_DIR, 'users.json');
const users = fs.existsSync(usersFile) ? JSON.parse(fs.readFileSync(usersFile, 'utf8')) : {};
const saveUsers = () => fs.writeFileSync(usersFile, JSON.stringify(users, null, 2));

function hashPassword(password) {
  const salt = crypto.randomBytes(16).toString('hex');
  const hash = crypto.scryptSync(password, salt, 64).toString('hex');
  return { salt, hash };
}
function verifyPassword(password, { salt, hash }) {
  const test = crypto.scryptSync(password, salt, 64).toString('hex');
  return crypto.timingSafeEqual(Buffer.from(test), Buffer.from(hash));
}
function makeToken(email) {
  const exp = Date.now() + 7 * 86400_000;
  const payload = `${email}|${exp}`;
  const sig = crypto.createHmac('sha256', SECRET).update(payload).digest('hex');
  return Buffer.from(`${payload}|${sig}`).toString('base64url');
}
function verifyToken(token) {
  try {
    const [email, exp, sig] = Buffer.from(token, 'base64url').toString().split('|');
    const expect = crypto.createHmac('sha256', SECRET).update(`${email}|${exp}`).digest('hex');
    if (!crypto.timingSafeEqual(Buffer.from(sig), Buffer.from(expect))) return null;
    if (Date.now() > Number(exp)) return null;
    return users[email] || null;
  } catch { return null; }
}

// DEV: сидируем арбитра платформы, чтобы спор было кому решать
if (DEV_MODE && !users['arbiter@paymesafe.online']) {
  users['arbiter@paymesafe.online'] = {
    email: 'arbiter@paymesafe.online',
    pass: hashPassword('arbiter123'),
    tronAddress: 'TArbiterPlatformAddr',
    isArbiter: true,
    createdAt: new Date().toISOString(),
  };
  saveUsers();
  console.log('[dev] арбитр: arbiter@paymesafe.online / arbiter123');
}

// ─────────────────────────── ДВИЖОК, ЧАТ, АРБИТРАЖ ───────────────────────────

const engine = new EscrowEngine({
  storePath: path.join(DATA_DIR, 'ledger.json'),
  walletService: { createDepositAddress: async () => PLATFORM_DEPOSIT_ADDRESS },
});
const chat = new DealChat(engine.ledger, path.join(DATA_DIR, 'chat.json'));
const arbiters = Object.values(users).filter(u => u.isArbiter).map(u => u.email);
const arbitration = new ArbitrationService(engine, chat, { arbiters });

// ─────────────────────────── СЕРИАЛИЗАЦИЯ ───────────────────────────

function dealView(d, viewerEmail) {
  const myRole = viewerEmail === d.buyer.email ? 'buyer'
    : viewerEmail === d.seller.email ? 'seller'
    : d.dispute?.arbiter === viewerEmail ? 'arbiter' : null;
  return {
    id: d.id, title: d.title, template: d.template, state: d.state,
    amount: fromBaseUnits(BigInt(d.amount)),
    requiredDeposit: fromBaseUnits(BigInt(d.requiredDeposit)),
    deposited: fromBaseUnits(engine.ledger.depositedFor(d.id)),
    feeBps: d.feeBps, depositAddress: d.depositAddress, deadline: d.deadline,
    buyer: { email: d.buyer.email, approved: d.buyer.approved },
    seller: { email: d.seller.email, approved: d.seller.approved },
    myRole,
    dispute: d.dispute || null,
    resolution: d.resolution || null,
    createdAt: d.createdAt,
  };
}

function journalView(dealId) {
  return engine.ledger.journal(dealId).map(e => ({
    ts: e.ts, type: e.type, amount: fromBaseUnits(BigInt(e.amount)), txid: e.txid,
  }));
}

const isParticipant = (d, email) =>
  d.buyer.email === email || d.seller.email === email || d.dispute?.arbiter === email;

// ─────────────────────────── HTTP-КАРКАС ───────────────────────────

function send(res, code, body) {
  const data = JSON.stringify(body);
  res.writeHead(code, {
    'Content-Type': 'application/json; charset=utf-8',
    'Access-Control-Allow-Origin': '*',
    'Access-Control-Allow-Headers': 'Content-Type, Authorization',
    'Access-Control-Allow-Methods': 'GET, POST, PUT, OPTIONS',
  });
  res.end(data);
}

function readBody(req) {
  return new Promise((resolve, reject) => {
    let raw = '';
    req.on('data', c => { raw += c; if (raw.length > 1e6) req.destroy(); });
    req.on('end', () => { try { resolve(raw ? JSON.parse(raw) : {}); } catch { reject(new Error('Bad JSON')); } });
  });
}

function auth(req) {
  const h = req.headers.authorization || '';
  const token = h.startsWith('Bearer ') ? h.slice(7) : null;
  return token ? verifyToken(token) : null;
}

// ─────────────────────────── РОУТЫ ───────────────────────────

const routes = [];
const route = (method, pattern, handler) => routes.push({ method, pattern, handler });

// ---- AUTH ----

route('POST', /^\/api\/auth\/register$/, async (req, res) => {
  const { email, password, tronAddress } = await readBody(req);
  if (!email || !password) return send(res, 400, { error: 'Email и пароль обязательны' });
  if (!tronAddress) return send(res, 400, { error: 'Нужен TRON-адрес для выплат/возвратов' });
  if (users[email]) return send(res, 409, { error: 'Такой пользователь уже есть' });
  users[email] = { email, pass: hashPassword(password), tronAddress, isArbiter: false, createdAt: new Date().toISOString() };
  saveUsers();
  send(res, 201, { token: makeToken(email), me: { email, tronAddress, isArbiter: false } });
});

route('POST', /^\/api\/auth\/login$/, async (req, res) => {
  const { email, password } = await readBody(req);
  const u = users[email];
  if (!u || !verifyPassword(password, u.pass)) return send(res, 401, { error: 'Неверный email или пароль' });
  send(res, 200, { token: makeToken(email), me: { email, tronAddress: u.tronAddress, isArbiter: !!u.isArbiter } });
});

// ---- DEALS ----

route('GET', /^\/api\/deals$/, async (req, res, user) => {
  const mine = engine.ledger.allDeals()
    .filter(d => isParticipant(d, user.email))
    .sort((a, b) => b.createdAt.localeCompare(a.createdAt))
    .map(d => dealView(d, user.email));
  send(res, 200, { deals: mine });
});

route('POST', /^\/api\/deals$/, async (req, res, user) => {
  const { title, amount, template = 'custom', role, counterpartyEmail, deadlineDays = 30 } = await readBody(req);
  if (!['buyer', 'seller'].includes(role)) return send(res, 400, { error: 'role: buyer или seller' });
  const other = users[counterpartyEmail];
  if (!other) return send(res, 400, { error: 'Контрагент должен сначала зарегистрироваться на платформе' });

  const meP = { email: user.email, tronAddress: user.tronAddress };
  const otherP = { email: other.email, tronAddress: other.tronAddress };
  const deal = await engine.createDeal({
    title, amount, template, deadlineDays,
    buyer: role === 'buyer' ? meP : otherP,
    seller: role === 'seller' ? meP : otherP,
  });
  chat.system(deal.id, `Сделка создана: «${title}» · $${fromBaseUnits(BigInt(deal.amount))} USDT · комиссия по 1% с каждой стороны. Ожидается подтверждение условий.`);
  send(res, 201, { deal: dealView(deal, user.email) });
});

route('GET', /^\/api\/deals\/([\w-]+)$/, async (req, res, user, m) => {
  const d = engine.ledger.getDeal(m[1]);
  if (!d || !isParticipant(d, user.email)) return send(res, 404, { error: 'Сделка не найдена' });
  send(res, 200, { deal: dealView(d, user.email), journal: journalView(d.id) });
});

route('POST', /^\/api\/deals\/([\w-]+)\/approve$/, async (req, res, user, m) => {
  const d = engine.ledger.getDeal(m[1]);
  if (!d || !isParticipant(d, user.email)) return send(res, 404, { error: 'Сделка не найдена' });
  const role = d.buyer.email === user.email ? 'buyer' : 'seller';
  const updated = await engine.approve(d.id, role);
  chat.system(d.id, role === 'buyer' ? 'Покупатель подтвердил условия сделки' : 'Продавец подтвердил условия сделки');
  if (updated.state === 'AWAITING_DEPOSIT') {
    chat.system(d.id, `Обе стороны согласились. Адрес пополнения: ${updated.depositAddress}. К переводу: $${fromBaseUnits(BigInt(updated.requiredDeposit))} USDT (сумма + 1% комиссии покупателя).`);
  }
  send(res, 200, { deal: dealView(updated, user.email) });
});

route('POST', /^\/api\/deals\/([\w-]+)\/release$/, async (req, res, user, m) => {
  const d = engine.ledger.getDeal(m[1]);
  if (!d || d.buyer.email !== user.email) return send(res, 403, { error: 'Выпустить средства может только покупатель' });
  const r = await engine.release(d.id, 'buyer');
  chat.system(d.id, `Покупатель подтвердил выполнение условий. Продавцу выплачено $${r.payout} USDT (комиссия $${r.fee}). Сделка завершена.`);
  send(res, 200, { deal: dealView(r.deal, user.email), payout: r.payout, fee: r.fee });
});

route('POST', /^\/api\/deals\/([\w-]+)\/dispute$/, async (req, res, user, m) => {
  const { reason } = await readBody(req);
  const r = await arbitration.openCase(m[1], { by: user.email, reason });
  send(res, 200, { deal: dealView(r.deal, user.email), arbiter: r.arbiter });
});

route('POST', /^\/api\/deals\/([\w-]+)\/evidence$/, async (req, res, user, m) => {
  const { text, attachments = [] } = await readBody(req);
  const msg = arbitration.submitEvidence(m[1], { email: user.email, text, attachments });
  send(res, 200, { message: msg });
});

route('POST', /^\/api\/deals\/([\w-]+)\/decide$/, async (req, res, user, m) => {
  if (!user.isArbiter) return send(res, 403, { error: 'Только арбитр платформы может выносить решение' });
  const { sellerBps, rationale } = await readBody(req);
  const r = await arbitration.decide(m[1], { arbiter: user.email, sellerBps: Number(sellerBps), rationale });
  send(res, 200, { deal: dealView(r.deal, user.email), payout: r.payout, fee: r.fee, refunded: r.refunded });
});

// ---- CHAT ----

route('GET', /^\/api\/deals\/([\w-]+)\/chat$/, async (req, res, user, m) => {
  send(res, 200, { messages: chat.history(m[1], user.email) });
});

route('POST', /^\/api\/deals\/([\w-]+)\/chat$/, async (req, res, user, m) => {
  const { text } = await readBody(req);
  const d = engine.ledger.getDeal(m[1]);
  // Сообщение арбитра идёт через его сервис (проверка назначения на дело)
  const msg = user.isArbiter && d?.dispute
    ? arbitration.arbiterMessage(m[1], { arbiter: user.email, text })
    : chat.post(m[1], { email: user.email, text });
  send(res, 200, { message: msg });
});

// ---- DEV: симуляция депозита (в проде это делает deposit-watcher из Tron) ----

route('POST', /^\/api\/dev\/deposit$/, async (req, res, user) => {
  if (!DEV_MODE) return send(res, 403, { error: 'Отключено вне DEV-режима' });
  const { dealId, amount } = await readBody(req);
  const d = engine.ledger.getDeal(dealId);
  if (!d || d.buyer.email !== user.email) return send(res, 403, { error: 'Депозит вносит покупатель' });
  const r = await engine.onDepositConfirmed(dealId, {
    amount: toBaseUnits(String(amount)),
    txid: 'devtx_' + crypto.randomBytes(6).toString('hex'),
    from: 'DEV_SIMULATOR',
  });
  chat.system(dealId, `Депозит подтверждён: +$${amount} USDT (симуляция testnet). Внесено $${fromBaseUnits(r.deposited)} из $${fromBaseUnits(r.required)}.` + (r.funded ? ' Средства заблокированы — сделка FUNDED.' : ''));
  send(res, 200, { deal: dealView(engine.ledger.getDeal(dealId), user.email), funded: r.funded });
});

// ---- STATS ----

route('GET', /^\/api\/stats$/, async (req, res) => {
  const rec = engine.reconcile();
  // GMV = всё, что когда-либо проходило через эскроу (сумма депозитов)
  const gmv = engine.ledger.journal()
    .filter(e => e.type === 'DEPOSIT')
    .reduce((sum, e) => sum + BigInt(e.amount), 0n);
  send(res, 200, {
    totalUsers: Object.keys(users).length,
    totalDeals: rec.deals.length,
    locked: rec.totalLocked,
    fees: rec.totalFees,
    gmv: fromBaseUnits(gmv),
  });
});

// ─────────────────────────── СЕРВЕР ───────────────────────────

const PUBLIC_ROUTES = [/^\/api\/auth\//, /^\/api\/stats$/];

const server = http.createServer(async (req, res) => {
  if (req.method === 'OPTIONS') return send(res, 204, {});
  const url = req.url.split('?')[0];

  // Статика
  if (req.method === 'GET' && (url === '/' || url === '/index.html')) {
    const file = path.join(__dirname, 'index.html');
    res.writeHead(200, { 'Content-Type': 'text/html; charset=utf-8' });
    return res.end(fs.readFileSync(file));
  }

  for (const r of routes) {
    const m = req.method === r.method && url.match(r.pattern);
    if (!m) continue;
    try {
      let user = null;
      if (!PUBLIC_ROUTES.some(p => p.test(url))) {
        user = auth(req);
        if (!user) return send(res, 401, { error: 'Требуется вход' });
      }
      return await r.handler(req, res, user, m);
    } catch (e) {
      return send(res, 400, { error: e.message });
    }
  }
  send(res, 404, { error: 'Not found' });
});

server.listen(PORT, () => {
  console.log(`
╔══════════════════════════════════════════════════╗
║  PayMeSafe — платформа запущена                   ║
║  http://localhost:${PORT}                            ║
║  DEV_MODE: ${DEV_MODE ? 'ON (депозиты симулируются)' : 'OFF'}         ║
║  Арбитр: arbiter@paymesafe.online / arbiter123    ║
╚══════════════════════════════════════════════════╝`);
});

module.exports = server;
