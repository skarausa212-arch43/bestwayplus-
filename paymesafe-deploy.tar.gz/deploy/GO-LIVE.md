# PayMeSafe — переход на реальные деньги (TRON / USDT TRC-20)

Сейчас платформа работает в режиме **DEV**: депозиты симулируются, реальные
средства не двигаются. Ниже — что сделать, чтобы перейти на реальный TRON.
Код уже готов: реальный режим (**LIVE**) включается САМ, как только на сервере
появляются оба секрета в окружении — `HOT_WALLET_KEY` и `ESCROW_MASTER_KEY`.
Без них ничего не переключается.

> ⚠️ ЮРИДИЧЕСКОЕ: приём реальных средств клиентов на кастодиальный кошелёк —
> это регулируемая деятельность. Сначала security-аудит и лицензия, потом
> реальные деньги. Ниже — техническая готовность, а не разрешение запускаться.

---

## Что уже сделано в коде
- `HOT_WALLET_KEY` + `ESCROW_MASTER_KEY` в env → сервер стартует в LIVE.
- На каждую сделку генерируется **отдельный** депозитный адрес (TronWalletService),
  приватные ключи шифруются AES-256-GCM и лежат в `data/keystore.json`.
- `deposit-watcher` опрашивает TronGrid и подтверждает поступления USDT.
- Выплаты/возвраты реально уходят через `payout-service` (`sendUSDT`).
- DEV-эндпоинт симуляции депозита автоматически выключается в LIVE.
- Мониторинг: `GET /api/admin/tron` (админом) → режим, сеть, адрес и баланс
  горячего кошелька, статус watcher'а.

## Порядок включения (сначала на TESTNET Nile!)

### 1. Установить зависимость на сервере
```bash
cd /opt/paymesafe
npm i tronweb@6.4.0        # единственная внешняя зависимость, нужна только для LIVE
```
(Деплой архива её не трогает — `node_modules` остаётся между обновлениями.)

### 2. Сгенерировать ключи
```bash
# мастер-ключ для шифрования депозитных ключей (32 байта hex)
openssl rand -hex 32
# горячий кошелёк: создайте новый TRON-аккаунт и возьмите его privateKey
node -e 'const {TronWeb}=require("tronweb");TronWeb.createAccount().then(a=>console.log("ADDR",a.address.base58,"\nKEY",a.privateKey))'
```
Получите бесплатный API-ключ на https://www.trongrid.io (Dashboard → API Keys).

### 3. Прописать переменные в systemd-юнит (НЕ в файлы проекта!)
`/etc/systemd/system/paymesafe.service` → секция `[Service]`:
```ini
Environment=TRON_NETWORK=nile
Environment=NILE_USDT_CONTRACT=<адрес тестового USDT в Nile>
Environment=TRONGRID_KEY=<ваш ключ TronGrid>
Environment=ESCROW_MASTER_KEY=<openssl rand -hex 32>
Environment=HOT_WALLET_KEY=<privateKey горячего кошелька>
Environment=ADMIN_PASSWORD=<надёжный пароль админки>
```
Затем:
```bash
systemctl daemon-reload && systemctl restart paymesafe
journalctl -u paymesafe -n 20 --no-pager   # должно быть: "Режим: LIVE · TRON nile"
```

### 4. Прогнать полный цикл на testnet
Получите тестовые TRX (кран Nile) на горячий кошелёк, застейкайте немного TRX
на энергию, создайте сделку, отправьте тестовый USDT на депозитный адрес сделки —
watcher должен подтвердить депозит, подтверждение обеими сторонами должно
реально отправить USDT продавцу. Проверяйте `GET /api/admin/tron`.

### 5. Только после аудита/лицензии — mainnet
Поменять `TRON_NETWORK=mainnet` (контракт USDT зашит в коде), новый горячий
кошелёк, застейкать TRX под энергию (иначе комиссии съедят маржу), включить
мониторинг ликвидности горячего кошелька.

## Безопасность (обязательно)
- `HOT_WALLET_KEY` и `ESCROW_MASTER_KEY` — ТОЛЬКО в env systemd, права `600`,
  никогда в git/чаты/логи.
- Горячий кошелёк держать «тонким»: излишки уводить на холодный.
- Для продакшена ключи выносят в KMS/HSM (AWS KMS, Vault) — env это уровень MVP.
- Регулярный `reconcile` (касса сходится) и бэкап `data/keystore.json`
  (без него теряется доступ к средствам на депозитных адресах).
