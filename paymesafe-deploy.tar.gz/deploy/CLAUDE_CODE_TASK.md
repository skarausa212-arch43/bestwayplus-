# Задание для Claude Code: развернуть PayMeSafe на сервере

Скопируйте текст ниже и вставьте в Claude Code (в терминале на машине,
с которой есть SSH-доступ к серверу). Архив paymesafe-deploy.tar.gz
должен лежать в текущей папке.

─────────────────────────── ПРОМПТ ───────────────────────────

Разверни платформу PayMeSafe на моём сервере. Данные:
- SSH: root@<IP_СЕРВЕРА>  (подставь мой реальный адрес/алиас)
- Архив приложения: ./paymesafe-deploy.tar.gz
- Домен (если есть): app.paymesafe.online — иначе пропусти шаги DNS/HTTPS

Шаги:
1. Скопируй архив на сервер: scp paymesafe-deploy.tar.gz root@<IP>:/tmp/
2. По SSH: распакуй в /tmp/paymesafe-deploy и запусти
   bash /tmp/paymesafe-deploy/deploy/install.sh app.paymesafe.online
   Скрипт сам ставит Node 20, копирует приложение в /opt/paymesafe,
   создаёт systemd-сервис paymesafe и nginx-прокси на порт 80.
3. Проверь: curl http://127.0.0.1:3001/api/stats должен вернуть JSON,
   systemctl status paymesafe — active (running).
4. Если домен указан и A-запись уже смотрит на сервер:
   apt install -y certbot python3-certbot-nginx
   certbot --nginx -d app.paymesafe.online --non-interactive --agree-tos -m <мой email>
5. Смени пароль арбитра: останови сервис, удали строку
   "arbiter@paymesafe.online" из /opt/paymesafe/data/users.json,
   запусти сервис, затем зарегистрируй арбитра заново через API с новым
   паролем и вручную поставь ему "isArbiter": true в users.json
   (после — systemctl restart paymesafe).
6. Настрой бэкап данных: cron-задача, раз в сутки копирующая
   /opt/paymesafe/data в /root/backups/paymesafe-$(date +%F).tar.gz,
   хранить последние 14 копий.
7. Открой в отчёте: URL платформы, статус сервиса, путь к бэкапам.

Не меняй логику приложения. Если что-то падает — покажи журнал:
journalctl -u paymesafe -n 50.

──────────────────────── КОНЕЦ ПРОМПТА ────────────────────────

## Что важно знать после деплоя

- DEV_MODE включён: депозиты «вносятся кнопкой» для демо. Реальные USDT
  требуют tron-watcher (escrow-engine/tron/, npm i tronweb, ключ TronGrid)
  и Environment=DEV_MODE=0 в /etc/systemd/system/paymesafe.service.
- Приватный ключ кошелька TYyr8571…C7Pr на сервер попадает ТОЛЬКО как
  env-переменная HOT_WALLET_KEY и только когда включаете реальные выплаты.
  Никогда не кладите его в файлы проекта и не отправляйте в чаты.
- Данные — JSON в /opt/paymesafe/data. Для нагрузки > пилота: PostgreSQL.
- Реальные деньги клиентов на этом адресе = кастодиальная деятельность.
  Лицензия и security-аудит — до запуска.
