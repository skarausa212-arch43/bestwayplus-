#!/bin/bash
# PayMeSafe — установка на Ubuntu 22.04/24.04
# Запуск НА СЕРВЕРЕ из папки с распакованным пакетом:  bash deploy/install.sh [домен]
set -e

DOMAIN="${1:-}"
APP_DIR=/opt/paymesafe

echo "══ 1/5 Node.js и nginx ══"
apt-get update -qq
apt-get install -y -qq nginx curl ca-certificates
if ! command -v node >/dev/null || [ "$(node -v | cut -c2-3)" -lt 18 ]; then
  curl -fsSL https://deb.nodesource.com/setup_20.x | bash -
  apt-get install -y -qq nodejs
fi
node -v

echo "══ 2/5 Копирую приложение в $APP_DIR ══"
mkdir -p $APP_DIR
cp -r "$(dirname "$0")/../server.js" "$(dirname "$0")/../index.html" "$(dirname "$0")/../escrow-engine" $APP_DIR/
mkdir -p $APP_DIR/data

echo "══ 3/5 systemd-сервис ══"
cat > /etc/systemd/system/paymesafe.service << 'EOF'
[Unit]
Description=PayMeSafe escrow platform
After=network.target

[Service]
WorkingDirectory=/opt/paymesafe
ExecStart=/usr/bin/node server.js
Restart=always
RestartSec=3
Environment=PORT=3001
Environment=PLATFORM_DEPOSIT_ADDRESS=TYyr8571CtVU1PyQ7Lam5uoJh73WCMC7Pr
# DEV_MODE=1 (по умолчанию): депозиты симулируются кнопкой.
# Для реальных USDT: раскомментируйте строку ниже и настройте tron-watcher (см. DEPLOY.md)
# Environment=DEV_MODE=0

[Install]
WantedBy=multi-user.target
EOF
systemctl daemon-reload
systemctl enable --now paymesafe
sleep 1
systemctl is-active paymesafe && echo "✓ сервис запущен"

echo "══ 4/5 nginx reverse proxy ══"
SERVER_NAME="${DOMAIN:-_}"
cat > /etc/nginx/sites-available/paymesafe << EOF
server {
  listen 80;
  server_name $SERVER_NAME;
  location / {
    proxy_pass http://127.0.0.1:3001;
    proxy_set_header Host \$host;
    proxy_set_header X-Real-IP \$remote_addr;
  }
}
EOF
ln -sf /etc/nginx/sites-available/paymesafe /etc/nginx/sites-enabled/paymesafe
rm -f /etc/nginx/sites-enabled/default
nginx -t && systemctl reload nginx

echo "══ 5/5 Проверка ══"
curl -s http://127.0.0.1:3001/api/stats && echo

if [ -n "$DOMAIN" ]; then
  echo "Для HTTPS выполните: apt install -y certbot python3-certbot-nginx && certbot --nginx -d $DOMAIN"
fi

echo
echo "╔════════════════════════════════════════════╗"
echo "║ Готово. Платформа: http://$(curl -s ifconfig.me 2>/dev/null || hostname -I | awk '{print $1}')"
echo "║ ⚠ СМЕНИТЕ пароль арбитра (arbiter123)!     ║"
echo "║ Данные: /opt/paymesafe/data (бэкапьте!)    ║"
echo "╚════════════════════════════════════════════╝"
