# PayMeSafe Escrow Engine — кастодиальный TRC-20 (USDT)

Движок, который держит деньги. Ядро протестировано (27 тестов), Tron-адаптеры
запускаются на вашей машине с tronweb.

## Архитектура

```
escrow-engine/
├── core/                      ← ЯДРО (zero dependencies, тестируется без сети)
│   ├── escrow-engine.js       машина состояний сделки + команды на деньги
│   ├── ledger.js              append-only журнал денег, идемпотентность по txid
│   └── fees.js                тарифная сетка из презентации, BigInt, без float
├── tron/                      ← АДАПТЕРЫ (нужен npm i tronweb, сеть)
│   ├── tron-wallet.js         депозитный адрес на каждую сделку, ключи в AES-256-GCM
│   ├── deposit-watcher.js     мониторинг входящих USDT через TronGrid
│   └── payout-service.js      выплаты с горячего кошелька + sweep депозитов
└── test-engine.js             27 тестов полного жизненного цикла
```

## Жизненный цикл сделки

```
CREATED → (обе стороны approve) → AWAITING_DEPOSIT → (депозит ≥ суммы) → FUNDED
FUNDED → release покупателем → RELEASED (продавцу минус комиссия)
FUNDED → спор → DISPUTED → арбитр → RELEASED или REFUNDED
AWAITING_DEPOSIT → дедлайн → EXPIRED (частичный депозит возвращается)
```

## Что уже проверено тестами

- Комиссии точно по вашей сетке: 2.5% / 2.0% / 1.0% / 0.75%
- Деньги в BigInt — ни одна копейка не теряется на округлении
- Идемпотентность: один txid зачисляется ровно один раз
- Депозит частями, переплата возвращается покупателю
- Продавец не может выпустить деньги сам себе
- Из терминальных состояний выйти нельзя
- Сверка кассы: locked = депозиты − выплаты − комиссии, всегда

## Запуск тестов ядра (без сети)

```bash
node test-engine.js
```

## Запуск на Nile testnet (на вашей машине)

```bash
npm i tronweb

# 1. Мастер-ключ для шифрования депозитных ключей
export ESCROW_MASTER_KEY=$(openssl rand -hex 32)

# 2. Горячий кошелёк: создайте на nileex.io, получите тестовые TRX/USDT из крана
export HOT_WALLET_KEY=<privkey горячего кошелька>
export NILE_USDT_CONTRACT=<адрес тестового USDT в Nile>

# 3. Соберите всё вместе:
node run-testnet.js
```

Пример `run-testnet.js`:

```js
const { EscrowEngine } = require('./core/escrow-engine');
const { TronWalletService } = require('./tron/tron-wallet');
const { PayoutService } = require('./tron/payout-service');
const { DepositWatcher } = require('./tron/deposit-watcher');

const wallets = new TronWalletService({ keystorePath: './keystore.json' });
const payouts = new PayoutService({ network: 'nile' });
const engine = new EscrowEngine({ storePath: './ledger.json', walletService: wallets, payoutService: payouts });
const watcher = new DepositWatcher({ engine, wallets, network: 'nile' });

watcher.start();
// Дальше дергайте engine.createDeal / approve / release из вашего backend.js
```

## Интеграция с backend.js

Замените in-memory логику эскроу в backend.js на вызовы движка:

| Endpoint                  | Вызов движка                                  |
|---------------------------|-----------------------------------------------|
| POST /api/deals           | engine.createDeal({...})                       |
| PUT  /api/deals/:id/approve | engine.approve(id, role)                     |
| POST /api/escrow/release  | engine.release(id, 'buyer')                    |
| POST /api/disputes        | engine.openDispute(id, {...})                  |
| POST /api/disputes/:id/resolve | engine.resolveDispute(id, {...})          |
| депозиты                  | НЕ через API — только watcher из блокчейна     |

Ключевое отличие от старого backend.js: депозит подтверждает НЕ пользователь
через POST-запрос, а watcher из блокчейна. Пользователь не может "сказать"
что заплатил — движок сам видит деньги в сети.

## ⚠️ Перед реальными деньгами — обязательно

1. **Ключи**: ESCROW_MASTER_KEY и HOT_WALLET_KEY в env — уровень testnet.
   Production: AWS KMS / HashiCorp Vault, разделение hot/cold, лимиты на
   горячем кошельке (например, не больше суточного оборота).
2. **Энергия Tron**: стейкайте TRX на горячем кошельке (Stake 2.0), иначе
   каждый USDT-перевод сжигает 13–27 TRX и убивает маржу мелких сделок.
3. **Аудит**: этот код должен посмотреть security-инженер. Особенно
   payout-service и хранение ключей. Это не формальность.
4. **Лицензия**: кастодиальная модель = вы храните чужие деньги = VASP.
   Без лицензии в выбранной юрисдикции запускаться на mainnet нельзя.
