/**
 * Tron Wallet Service — депозитные адреса под каждую сделку
 *
 * Запускается на ВАШЕЙ машине (нужен npm i tronweb).
 * Схема: на каждую сделку генерируется отдельный Tron-аккаунт.
 * Приватный ключ шифруется AES-256-GCM мастер-ключом из env и
 * сохраняется в keystore-файл. Адрес отдаётся покупателю для депозита.
 *
 * ⚠️ PRODUCTION: мастер-ключ в env — это уровень MVP/testnet.
 * Для реальных денег ключи держат в KMS/HSM (AWS KMS, HashiCorp Vault),
 * а горячий кошелёк отделяют от холодного. Это не опция, это требование.
 */

const crypto = require('crypto');
const fs = require('fs');
// tronweb 6.x экспортирует класс как именованное свойство { TronWeb }.
// Поддерживаем и старый стиль (module === class) на всякий случай.
const _tw = require('tronweb');
const TronWeb = _tw.TronWeb || _tw;

class TronWalletService {
  constructor({ keystorePath = './keystore.json', masterKeyHex = process.env.ESCROW_MASTER_KEY }) {
    if (!masterKeyHex || masterKeyHex.length !== 64) {
      throw new Error('ESCROW_MASTER_KEY must be 32 bytes hex. Generate: openssl rand -hex 32');
    }
    this.masterKey = Buffer.from(masterKeyHex, 'hex');
    this.keystorePath = keystorePath;
    this.keystore = fs.existsSync(keystorePath)
      ? JSON.parse(fs.readFileSync(keystorePath, 'utf8'))
      : {};
  }

  /** Новый депозитный адрес для сделки */
  async createDepositAddress(dealId) {
    if (this.keystore[dealId]) return this.keystore[dealId].address; // идемпотентно
    const account = await TronWeb.createAccount();
    this.keystore[dealId] = {
      address: account.address.base58,
      encKey: this._encrypt(account.privateKey),
      createdAt: new Date().toISOString(),
    };
    this._persist();
    return account.address.base58;
  }

  /** Приватный ключ депозитного адреса (нужен для sweep) */
  getPrivateKey(dealId) {
    const rec = this.keystore[dealId];
    if (!rec) throw new Error(`No deposit address for deal ${dealId}`);
    return this._decrypt(rec.encKey);
  }

  addressFor(dealId) {
    return this.keystore[dealId]?.address || null;
  }

  allAddresses() {
    return Object.entries(this.keystore).map(([dealId, v]) => ({ dealId, address: v.address }));
  }

  _encrypt(plaintext) {
    const iv = crypto.randomBytes(12);
    const cipher = crypto.createCipheriv('aes-256-gcm', this.masterKey, iv);
    const enc = Buffer.concat([cipher.update(plaintext, 'utf8'), cipher.final()]);
    return {
      iv: iv.toString('hex'),
      tag: cipher.getAuthTag().toString('hex'),
      data: enc.toString('hex'),
    };
  }

  _decrypt({ iv, tag, data }) {
    const decipher = crypto.createDecipheriv('aes-256-gcm', this.masterKey, Buffer.from(iv, 'hex'));
    decipher.setAuthTag(Buffer.from(tag, 'hex'));
    return Buffer.concat([decipher.update(Buffer.from(data, 'hex')), decipher.final()]).toString('utf8');
  }

  _persist() {
    const tmp = this.keystorePath + '.tmp';
    fs.writeFileSync(tmp, JSON.stringify(this.keystore, null, 2));
    fs.renameSync(tmp, this.keystorePath);
  }
}

module.exports = { TronWalletService };
