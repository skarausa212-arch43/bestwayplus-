/**
 * Payout Service — выплаты USDT с горячего кошелька + sweep депозитов
 *
 * Два денежных потока:
 *   1. PAYOUT/REFUND: горячий кошелёк → продавец/покупатель
 *   2. SWEEP: депозитный адрес сделки → горячий кошелёк (консолидация)
 *
 * ⚠️ Про энергию Tron (важно, это все забывают):
 * Перевод TRC-20 стоит ~65 000 energy. Без стейкинга TRX сеть сжигает
 * ~13–27 TRX за каждый перевод. Для бизнеса правильный путь —
 * застейкать TRX на горячем кошельке (Stake 2.0) и получать энергию
 * бесплатно. Иначе комиссии съедят маржу с мелких сделок.
 *
 * ⚠️ Депозитные адреса: у свежего адреса нет TRX вообще, поэтому
 * sweep требует сначала закинуть на него немного TRX на комиссию
 * (или использовать делегирование энергии). Реализовано ниже.
 */

const TronWeb = require('tronweb');

class PayoutService {
  /**
   * @param {object} opts
   * @param {string} opts.network 'mainnet' | 'nile'
   * @param {string} opts.hotWalletKey приватный ключ горячего кошелька (env!)
   * @param {string} opts.trongridKey
   */
  constructor({ network = 'nile', hotWalletKey = process.env.HOT_WALLET_KEY, trongridKey = '' }) {
    if (!hotWalletKey) throw new Error('HOT_WALLET_KEY env var is required');

    const nets = {
      mainnet: { api: 'https://api.trongrid.io', usdt: 'TR7NHqjeKQxGTCi8q8ZY4pL8otSzgjLj6t' },
      nile:    { api: 'https://nile.trongrid.io', usdt: process.env.NILE_USDT_CONTRACT || '' },
    };
    this.net = nets[network];

    this.tronWeb = new TronWeb({
      fullHost: this.net.api,
      headers: trongridKey ? { 'TRON-PRO-API-KEY': trongridKey } : {},
      privateKey: hotWalletKey,
    });
    this.hotAddress = this.tronWeb.address.fromPrivateKey(hotWalletKey);
  }

  /** Отправить USDT получателю. Возвращает txid. Движок пишет его в леджер. */
  async sendUSDT(toAddress, amountUnits) {
    if (!this.tronWeb.isAddress(toAddress)) throw new Error(`Invalid TRON address: ${toAddress}`);
    const contract = await this.tronWeb.contract().at(this.net.usdt);

    const tx = await contract.transfer(toAddress, amountUnits.toString()).send({
      feeLimit: 100_000_000, // максимум 100 TRX на комиссию — защита от сюрпризов
    });
    // tx — это txid строкой
    await this._waitConfirmed(tx);
    return tx;
  }

  /** Собрать USDT с депозитного адреса сделки на горячий кошелёк */
  async sweepDeposit(depositPrivateKey) {
    const depositTron = new TronWeb({
      fullHost: this.net.api,
      privateKey: depositPrivateKey,
    });
    const depositAddr = depositTron.address.fromPrivateKey(depositPrivateKey);

    const contract = await depositTron.contract().at(this.net.usdt);
    const balance = await contract.balanceOf(depositAddr).call();
    const units = BigInt(balance.toString());
    if (units === 0n) return { swept: 0n };

    // На депозитном адресе нет TRX → закидываем на комиссию с горячего
    const trxBalance = await this.tronWeb.trx.getBalance(depositAddr);
    if (trxBalance < 30_000_000) { // < 30 TRX
      await this.tronWeb.trx.sendTransaction(depositAddr, 30_000_000); // 30 TRX
      await new Promise(r => setTimeout(r, 5000)); // ждём попадания в блок
    }

    const tx = await contract.transfer(this.hotAddress, units.toString()).send({
      feeLimit: 100_000_000,
    });
    await this._waitConfirmed(tx);
    return { swept: units, txid: tx };
  }

  /** Баланс горячего кошелька — для мониторинга ликвидности */
  async hotWalletBalance() {
    const contract = await this.tronWeb.contract().at(this.net.usdt);
    const usdt = await contract.balanceOf(this.hotAddress).call();
    const trx = await this.tronWeb.trx.getBalance(this.hotAddress);
    return { usdtUnits: BigInt(usdt.toString()), trxSun: trx };
  }

  async _waitConfirmed(txid, timeoutMs = 60_000) {
    const start = Date.now();
    while (Date.now() - start < timeoutMs) {
      try {
        const info = await this.tronWeb.trx.getTransactionInfo(txid);
        if (info && info.id) {
          if (info.receipt?.result && info.receipt.result !== 'SUCCESS') {
            throw new Error(`TX ${txid} failed: ${info.receipt.result}`);
          }
          return info;
        }
      } catch (e) { /* ещё не в блоке */ }
      await new Promise(r => setTimeout(r, 3000));
    }
    throw new Error(`TX ${txid} not confirmed within ${timeoutMs / 1000}s`);
  }
}

module.exports = { PayoutService };
