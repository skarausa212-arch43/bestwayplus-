/**
 * Deposit Watcher — следит за входящими USDT на депозитные адреса
 *
 * Опрашивает TronGrid API каждые N секунд. Когда видит входящий
 * TRC-20 трансфер USDT на адрес сделки и транзакция солидифицирована
 * (≈19+ блоков, у Tron это встроенное понятие "solidified"),
 * сообщает движку: engine.onDepositConfirmed(...).
 *
 * Идемпотентность обеспечивает леджер (по txid), поэтому watcher
 * может безопасно перезапускаться и перечитывать историю.
 */

const { toBaseUnits } = require('../core/fees');

class DepositWatcher {
  /**
   * @param {object} opts
   * @param {EscrowEngine} opts.engine
   * @param {TronWalletService} opts.wallets
   * @param {string} opts.network  'mainnet' | 'nile' (testnet)
   * @param {string} opts.trongridKey  API key с trongrid.io (бесплатный)
   * @param {number} opts.pollMs  период опроса
   */
  constructor({ engine, wallets, network = 'nile', trongridKey = '', pollMs = 15_000 }) {
    this.engine = engine;
    this.wallets = wallets;
    this.pollMs = pollMs;
    this.trongridKey = trongridKey;
    this.timer = null;

    const nets = {
      mainnet: {
        api: 'https://api.trongrid.io',
        // Официальный контракт USDT TRC-20 (Tether) в mainnet:
        usdt: 'TR7NHqjeKQxGTCi8q8ZY4pL8otSzgjLj6t',
      },
      nile: {
        api: 'https://nile.trongrid.io',
        usdt: process.env.NILE_USDT_CONTRACT || '', // тестовый USDT задаётся в env
      },
    };
    this.net = nets[network];
    if (!this.net) throw new Error(`Unknown network: ${network}`);
    if (!this.net.usdt) throw new Error('USDT contract address is not configured for this network');
  }

  start() {
    console.log(`[watcher] polling every ${this.pollMs / 1000}s on ${this.net.api}`);
    this.timer = setInterval(() => this.tick().catch(e => console.error('[watcher]', e.message)), this.pollMs);
    return this.tick(); // первый проход сразу
  }

  stop() { clearInterval(this.timer); }

  /** Один проход: проверить все активные депозитные адреса */
  async tick() {
    const active = this.engine.ledger.allDeals()
      .filter(d => ['AWAITING_DEPOSIT', 'FUNDED'].includes(d.state) && d.depositAddress);

    for (const deal of active) {
      const transfers = await this._fetchIncomingUSDT(deal.depositAddress);
      for (const t of transfers) {
        const result = await this.engine.onDepositConfirmed(deal.id, {
          amount: BigInt(t.value),           // TronGrid отдаёт value уже в базовых единицах
          txid: t.transaction_id,
          from: t.from,
        });
        if (result.credited) {
          console.log(`[watcher] deal ${deal.id.slice(0, 8)}: +${t.value} units, funded=${result.funded}`);
        }
      }
      // Заодно проверяем дедлайн
      await this.engine.expireIfDue(deal.id);
    }
  }

  /** Подтверждённые входящие USDT-трансферы на адрес */
  async _fetchIncomingUSDT(address) {
    const url = `${this.net.api}/v1/accounts/${address}/transactions/trc20` +
      `?only_confirmed=true&only_to=true&contract_address=${this.net.usdt}&limit=50`;
    const res = await fetch(url, {
      headers: this.trongridKey ? { 'TRON-PRO-API-KEY': this.trongridKey } : {},
    });
    if (!res.ok) throw new Error(`TronGrid ${res.status} for ${address}`);
    const json = await res.json();
    // only_confirmed=true означает: транзакция в солидифицированном блоке —
    // это и есть финальность Tron (не откатится)
    return (json.data || []).filter(t =>
      t.to === address &&
      t.token_info?.address === this.net.usdt &&
      t.type === 'Transfer'
    );
  }
}

module.exports = { DepositWatcher };
