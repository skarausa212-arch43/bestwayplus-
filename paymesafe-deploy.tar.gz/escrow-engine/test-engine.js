/**
 * Тесты ядра эскроу-движка. Zero dependencies — только node.
 * Запуск: node test-engine.js
 */

const assert = require('assert');
const { EscrowEngine } = require('./core/escrow-engine');
const { toBaseUnits, fromBaseUnits, sideFee, requiredDeposit } = require('./core/fees');

let passed = 0, failed = 0;
async function test(name, fn) {
  try { await fn(); console.log(`  ✅ ${name}`); passed++; }
  catch (e) { console.log(`  ❌ ${name}\n     → ${e.message}`); failed++; }
}

const buyer = { email: 'buyer@test.com', tronAddress: 'TBuyerRefundAddr123' };
const seller = { email: 'seller@test.com', tronAddress: 'TSellerPayoutAddr456' };

(async () => {
  console.log('\n══════ 1. КОМИССИИ (1% с каждой стороны) ══════');

  await test('$25,000: покупатель вносит $25,250 (сумма + 1%)', () => {
    assert.equal(fromBaseUnits(requiredDeposit(toBaseUnits('25000'))), '25250');
  });
  await test('$25,000: комиссия каждой стороны $250', () => {
    assert.equal(fromBaseUnits(sideFee(toBaseUnits('25000'))), '250');
  });
  await test('$1,200,000: по $12,000 с каждой стороны (сценарий №4)', () => {
    assert.equal(fromBaseUnits(sideFee(toBaseUnits('1200000'))), '12000');
  });
  await test('копейки не теряются: 1% от $0.01 округляется вверх', () => {
    assert.ok(sideFee(toBaseUnits('0.01')) > 0n);
  });
  await test('кривая сумма отклоняется ("12,5" / "abc")', () => {
    assert.throws(() => toBaseUnits('12,5'));
    assert.throws(() => toBaseUnits('abc'));
  });

  console.log('\n══════ 2. СЧАСТЛИВЫЙ ПУТЬ: Copart $25,000 ══════');

  const engine = new EscrowEngine(); // in-memory, без Tron — демо-адаптеры
  let deal;

  await test('сделка создаётся в CREATED', async () => {
    deal = await engine.createDeal({
      title: 'Lixiang L7 — Copart', amount: '25000',
      buyer, seller, template: 'car-auction',
    });
    assert.equal(deal.state, 'CREATED');
    assert.equal(deal.feeBps, 100); // 1% с каждой стороны
    assert.equal(fromBaseUnits(BigInt(deal.requiredDeposit)), '25250');
  });

  await test('депозитный адрес НЕ выдаётся до одобрения обеих сторон', async () => {
    await engine.approve(deal.id, 'buyer');
    assert.equal(engine.ledger.getDeal(deal.id).depositAddress, null);
  });

  await test('обе стороны одобрили → AWAITING_DEPOSIT + адрес', async () => {
    await engine.approve(deal.id, 'seller');
    const d = engine.ledger.getDeal(deal.id);
    assert.equal(d.state, 'AWAITING_DEPOSIT');
    assert.ok(d.depositAddress);
  });

  await test('нельзя выпустить деньги до депозита', async () => {
    await assert.rejects(() => engine.release(deal.id), /Invalid state/);
  });

  await test('частичный депозит $10k → ещё не FUNDED', async () => {
    const r = await engine.onDepositConfirmed(deal.id, {
      amount: toBaseUnits('10000'), txid: 'tx_part_1', from: 'TBuyerWallet',
    });
    assert.equal(r.funded, false);
    assert.equal(engine.ledger.getDeal(deal.id).state, 'AWAITING_DEPOSIT');
  });

  await test('дубль txid не зачисляется повторно (идемпотентность)', async () => {
    const r = await engine.onDepositConfirmed(deal.id, {
      amount: toBaseUnits('10000'), txid: 'tx_part_1', from: 'TBuyerWallet',
    });
    assert.equal(r.credited, false);
    assert.equal(fromBaseUnits(engine.ledger.depositedFor(deal.id)), '10000');
  });

  await test('депозит $25,000 без комиссии покупателя → ещё НЕ FUNDED', async () => {
    const r = await engine.onDepositConfirmed(deal.id, {
      amount: toBaseUnits('15000'), txid: 'tx_part_2', from: 'TBuyerWallet',
    });
    assert.equal(r.funded, false); // внесено 25000, нужно 25250
  });

  await test('доплата комиссии $250 → FUNDED', async () => {
    const r = await engine.onDepositConfirmed(deal.id, {
      amount: toBaseUnits('250'), txid: 'tx_part_3', from: 'TBuyerWallet',
    });
    assert.equal(r.funded, true);
    assert.equal(engine.ledger.getDeal(deal.id).state, 'FUNDED');
  });

  await test('продавец НЕ может сам себе выпустить деньги', async () => {
    await assert.rejects(() => engine.release(deal.id, 'seller'), /Only the buyer/);
  });

  await test('release: продавцу $24,750, платформе $500 (1%+1%)', async () => {
    const r = await engine.release(deal.id, 'buyer');
    assert.equal(r.payout, '24750'); // 25000 − 1%
    assert.equal(r.fee, '500');      // 250 продавца + 250 покупателя
    assert.equal(r.deal.state, 'RELEASED');
  });

  await test('после RELEASED сделку нельзя трогать', async () => {
    await assert.rejects(() => engine.release(deal.id), /Invalid state/);
    await assert.rejects(() => engine.openDispute(deal.id, { by: 'buyer', reason: 'x' }), /Invalid state/);
  });

  console.log('\n══════ 3. СПОР: возврат покупателю ══════');

  let d2;
  await test('сделка $3,500 → FUNDED', async () => {
    d2 = await engine.createDeal({ title: 'Landing design', amount: '3500', buyer, seller });
    await engine.approve(d2.id, 'buyer');
    await engine.approve(d2.id, 'seller');
    await engine.onDepositConfirmed(d2.id, { amount: toBaseUnits('3535'), txid: 'tx_d2', from: 'TB' }); // 3500 + 1%
    assert.equal(engine.ledger.getDeal(d2.id).state, 'FUNDED');
  });

  await test('покупатель открывает спор → DISPUTED', async () => {
    await engine.openDispute(d2.id, { by: 'buyer', reason: 'Работа не соответствует ТЗ' });
    assert.equal(engine.ledger.getDeal(d2.id).state, 'DISPUTED');
  });

  await test('решение за покупателя → возврат ВСЕГО депозита $3,535 (включая его 1%)', async () => {
    const r = await engine.resolveDispute(d2.id, { winner: 'buyer', arbiter: 'admin@paymesafe' });
    assert.equal(r.refunded, '3535'); // платформа не зарабатывает на сорванной сделке
    assert.equal(r.deal.state, 'REFUNDED');
  });

  console.log('\n══════ 4. СПОР: решение в пользу продавца ══════');

  let d3;
  await test('спор → арбитр за продавца → RELEASED с комиссией', async () => {
    d3 = await engine.createDeal({ title: 'Wholesale pipes', amount: '8000', buyer, seller });
    await engine.approve(d3.id, 'buyer');
    await engine.approve(d3.id, 'seller');
    await engine.onDepositConfirmed(d3.id, { amount: toBaseUnits('8080'), txid: 'tx_d3', from: 'TB' });
    await engine.openDispute(d3.id, { by: 'seller', reason: 'Покупатель молчит после доставки' });
    const r = await engine.resolveDispute(d3.id, { winner: 'seller', arbiter: 'admin@paymesafe' });
    assert.equal(r.payout, '7920'); // 8000 − 1%
    assert.equal(r.fee, '160');   // 80 + 80
  });

  console.log('\n══════ 5. ДЕДЛАЙН И ОТМЕНА ══════');

  await test('дедлайн прошёл без депозита → EXPIRED', async () => {
    const d = await engine.createDeal({ title: 'Expired deal', amount: '500', buyer, seller, deadlineDays: 0 });
    await engine.approve(d.id, 'buyer');
    await engine.approve(d.id, 'seller');
    await engine.expireIfDue(d.id, new Date(Date.now() + 1000));
    assert.equal(engine.ledger.getDeal(d.id).state, 'EXPIRED');
  });

  await test('дедлайн с частичным депозитом → возврат покупателю + EXPIRED', async () => {
    const d = await engine.createDeal({ title: 'Partial expired', amount: '1000', buyer, seller, deadlineDays: 0 });
    await engine.approve(d.id, 'buyer');
    await engine.approve(d.id, 'seller');
    await engine.onDepositConfirmed(d.id, { amount: toBaseUnits('400'), txid: 'tx_exp', from: 'TB' });
    await engine.expireIfDue(d.id, new Date(Date.now() + 1000));
    const refunds = engine.ledger.journal(d.id).filter(e => e.type === 'REFUND');
    assert.equal(refunds.length, 1);
    assert.equal(fromBaseUnits(BigInt(refunds[0].amount)), '400');
  });

  await test('cancel с частичным депозитом запрещён (только через возврат)', async () => {
    const d = await engine.createDeal({ title: 'No cancel', amount: '100', buyer, seller, deadlineDays: 0 });
    await engine.approve(d.id, 'buyer');
    await engine.approve(d.id, 'seller');
    // Частичный депозит: сделка остаётся в AWAITING_DEPOSIT, но деньги уже есть
    await engine.onDepositConfirmed(d.id, { amount: toBaseUnits('50'), txid: 'tx_nc', from: 'TB' });
    await assert.rejects(() => engine.cancel(d.id), /use dispute/);
    // Закрываем через дедлайн → возврат $50 покупателю, касса сходится
    await engine.expireIfDue(d.id, new Date(Date.now() + 1000));
    assert.equal(engine.ledger.getDeal(d.id).state, 'EXPIRED');
  });

  await test('cancel полностью FUNDED сделки тоже запрещён', async () => {
    const d = await engine.createDeal({ title: 'No cancel funded', amount: '100', buyer, seller });
    await engine.approve(d.id, 'buyer');
    await engine.approve(d.id, 'seller');
    await engine.onDepositConfirmed(d.id, { amount: toBaseUnits('101'), txid: 'tx_ncf', from: 'TB' });
    await assert.rejects(() => engine.cancel(d.id), /Invalid state/);
    // Закрываем через release, чтобы в кассе не висел остаток
    await engine.release(d.id, 'buyer');
  });

  console.log('\n══════ 6. ЗАЩИТА ОТ ГЛУПОСТЕЙ ══════');

  await test('покупатель == продавец → отказ', async () => {
    await assert.rejects(() => engine.createDeal({
      title: 'x', amount: '100', buyer, seller: { email: buyer.email, tronAddress: 'T1' },
    }), /different parties/);
  });

  await test('продавец без Tron-адреса → отказ', async () => {
    await assert.rejects(() => engine.createDeal({
      title: 'x', amount: '100', buyer, seller: { email: 's@s.com' },
    }), /TRON payout address/);
  });

  console.log('\n══════ 7. СВЕРКА КАССЫ ══════');

  await test('леджер сходится: locked = депозиты − выплаты − комиссии', async () => {
    const rec = engine.reconcile();
    console.log(`     Заблокировано сейчас: $${rec.totalLocked} | Комиссии платформы: $${rec.totalFees}`);
    // Все сделки закрыты (кроме expired partial у которой refund) → locked должен быть 0
    assert.equal(rec.totalLockedUnits, '0');
  });

  console.log(`\n${'═'.repeat(50)}`);
  console.log(`ИТОГО: ${passed} passed, ${failed} failed`);
  process.exit(failed ? 1 : 0);
})();
