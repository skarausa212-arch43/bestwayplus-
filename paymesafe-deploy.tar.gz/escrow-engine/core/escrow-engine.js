/**
 * PayMeSafe Escrow Engine — ядро (машина состояний сделки)
 *
 * Жизненный цикл:
 *
 *   CREATED ──approve×2──▶ AWAITING_DEPOSIT ──deposit≥amount──▶ FUNDED
 *      │                        │                                 │
 *      │cancel                  │deadline                         ├─release──▶ RELEASED (продавцу, минус fee)
 *      ▼                        ▼                                 ├─dispute──▶ DISPUTED
 *   CANCELLED               EXPIRED                               │              ├─resolve(seller)─▶ RELEASED
 *                                                                 │              └─resolve(buyer)──▶ REFUNDED
 *
 * Ядро не знает про Tron. Ему сообщают о событиях (депозит подтверждён),
 * оно решает, что делать с деньгами, и отдаёт команды на выплату.
 * Так его можно тестировать без сети — что мы и делаем.
 */

const crypto = require('crypto');
const { toBaseUnits, fromBaseUnits, sideFee, requiredDeposit, settlement, SIDE_FEE_BPS } = require('./fees');
const { Ledger } = require('./ledger');

const STATES = ['CREATED', 'AWAITING_DEPOSIT', 'FUNDED', 'RELEASED', 'REFUNDED', 'DISPUTED', 'EXPIRED', 'CANCELLED'];

// Какие переходы разрешены. Всё остальное — ошибка, а не "тихо проигнорировали".
const TRANSITIONS = {
  CREATED:          ['AWAITING_DEPOSIT', 'CANCELLED'],
  AWAITING_DEPOSIT: ['FUNDED', 'EXPIRED', 'CANCELLED'],
  FUNDED:           ['RELEASED', 'DISPUTED'],
  DISPUTED:         ['RELEASED', 'REFUNDED'],
  RELEASED: [], REFUNDED: [], EXPIRED: [], CANCELLED: [],
};

class EscrowEngine {
  /**
   * @param {object} opts
   * @param {string} opts.storePath  путь к JSON-леджеру (null = in-memory)
   * @param {object} opts.walletService  адаптер кошельков (createDepositAddress)
   * @param {object} opts.payoutService  адаптер выплат (sendUSDT)
   */
  constructor({ storePath = null, walletService = null, payoutService = null } = {}) {
    this.ledger = new Ledger(storePath);
    this.wallets = walletService;
    this.payouts = payoutService;
  }

  // ───────────────────────── СОЗДАНИЕ ─────────────────────────

  async createDeal({ title, amount, buyer, seller, deadlineDays = 30, template = 'custom' }) {
    if (!buyer?.email || !seller?.email) throw new Error('Buyer and seller emails are required');
    if (buyer.email === seller.email) throw new Error('Buyer and seller must be different parties');
    const amountUnits = toBaseUnits(amount);
    if (amountUnits <= 0n) throw new Error('Amount must be positive');
    if (!seller.tronAddress) throw new Error('Seller must provide a TRON payout address');

    const deal = {
      id: crypto.randomUUID(),
      title, template,
      amount: amountUnits.toString(),
      requiredDeposit: requiredDeposit(amountUnits).toString(), // сумма + 1% покупателя
      feeBps: Number(SIDE_FEE_BPS), // 1% с каждой стороны
      buyer: { email: buyer.email, tronAddress: buyer.tronAddress || null, approved: false },
      seller: { email: seller.email, tronAddress: seller.tronAddress, approved: false },
      state: 'CREATED',
      depositAddress: null,
      deadline: new Date(Date.now() + deadlineDays * 86400_000).toISOString(),
      createdAt: new Date().toISOString(),
      history: [{ ts: new Date().toISOString(), event: 'created' }],
    };
    this.ledger.putDeal(deal);
    return deal;
  }

  // ─────────────────────── СОГЛАСОВАНИЕ ───────────────────────

  async approve(dealId, party /* 'buyer' | 'seller' */) {
    const deal = this._deal(dealId);
    this._assertState(deal, ['CREATED']);
    if (!['buyer', 'seller'].includes(party)) throw new Error('party must be buyer or seller');
    deal[party].approved = true;
    deal.history.push({ ts: new Date().toISOString(), event: `${party}_approved` });

    // Обе стороны согласились → выдаём уникальный депозитный адрес
    if (deal.buyer.approved && deal.seller.approved) {
      deal.depositAddress = this.wallets
        ? await this.wallets.createDepositAddress(deal.id)
        : `TDEMO_${deal.id.slice(0, 8)}`; // заглушка в тестах без Tron
      this._transition(deal, 'AWAITING_DEPOSIT', 'both_approved');
    }
    this.ledger.putDeal(deal);
    return deal;
  }

  // ───────────────────────── ДЕПОЗИТ ─────────────────────────
  // Вызывается watcher'ом, когда транзакция набрала подтверждения.

  async onDepositConfirmed(dealId, { amount, txid, from }) {
    const deal = this._deal(dealId);
    this._assertState(deal, ['AWAITING_DEPOSIT', 'FUNDED']); // доплата частями допустима

    const { duplicate } = this.ledger.append({
      dealId, type: 'DEPOSIT', amount, txid, meta: { from },
    });
    if (duplicate) return { deal, credited: false, reason: 'txid already processed' };

    deal.history.push({ ts: new Date().toISOString(), event: 'deposit', txid, amount: amount.toString() });

    const deposited = this.ledger.depositedFor(dealId);
    const required = BigInt(deal.requiredDeposit);
    if (deal.state === 'AWAITING_DEPOSIT' && deposited >= required) {
      this._transition(deal, 'FUNDED', 'deposit_complete');
    }
    this.ledger.putDeal(deal);
    return { deal, credited: true, deposited, required, funded: deposited >= required };
  }

  // ───────────────────────── ВЫПЛАТА ─────────────────────────

  async release(dealId, initiatedBy = 'buyer') {
    const deal = this._deal(dealId);
    this._assertState(deal, ['FUNDED']);
    if (initiatedBy !== 'buyer') throw new Error('Only the buyer can release funds');
    return this._payoutToSeller(deal, 'buyer_release');
  }

  async openDispute(dealId, { by, reason }) {
    const deal = this._deal(dealId);
    this._assertState(deal, ['FUNDED']);
    deal.dispute = { by, reason, openedAt: new Date().toISOString() };
    this._transition(deal, 'DISPUTED', `dispute_by_${by}`);
    this.ledger.putDeal(deal);
    return deal;
  }

  async resolveDispute(dealId, { winner /* 'seller' | 'buyer' */, arbiter }) {
    // Полная победа — частный случай сплита: 100% или 0% продавцу
    if (winner === 'seller') return this.resolveDisputeSplit(dealId, { sellerBps: 10000, arbiter });
    if (winner === 'buyer') return this.resolveDisputeSplit(dealId, { sellerBps: 0, arbiter });
    throw new Error('winner must be seller or buyer');
  }

  /**
   * Частичное решение спора: арбитр делит сумму сделки между сторонами.
   * sellerBps — доля продавца в basis points (7000 = 70% продавцу, 30% покупателю).
   * Комиссия платформы берётся ТОЛЬКО с доли продавца по ставке,
   * зафиксированной при создании сделки. Возврат покупателю — без комиссии.
   *
   * Инвариант: депозит = выплата продавцу + комиссия + возврат покупателю.
   */
  async resolveDisputeSplit(dealId, { sellerBps, arbiter }) {
    const deal = this._deal(dealId);
    this._assertState(deal, ['DISPUTED']);
    if (!Number.isInteger(sellerBps) || sellerBps < 0 || sellerBps > 10000) {
      throw new Error('sellerBps must be an integer between 0 and 10000');
    }

    const deposited = this.ledger.depositedFor(dealId);
    const base = BigInt(deal.amount);
    const sellerGross = base * BigInt(sellerBps) / 10000n;
    // 1% с каждой стороны — только с выпущенной продавцу части.
    // Невыпущенная часть возвращается покупателю целиком, включая его 1%.
    const s = settlement(deposited, sellerGross);
    const fee = s.feeTotal;
    const sellerNet = s.sellerNet;
    const buyerRefund = s.buyerBack;

    deal.dispute.resolvedBy = arbiter;
    deal.dispute.sellerBps = sellerBps;
    deal.dispute.resolvedAt = new Date().toISOString();

    const result = { sellerNet, fee, buyerRefund, txids: {} };

    if (sellerNet > 0n) {
      result.txids.payoutTxid = await this._send(deal.seller.tronAddress, sellerNet, deal.id, 'PAYOUT', `split_${sellerBps}bps`);
    }
    if (fee > 0n) {
      this.ledger.append({ dealId: deal.id, type: 'FEE', amount: fee, meta: { reason: `split_${sellerBps}bps` } });
    }
    if (buyerRefund > 0n) {
      if (!deal.buyer.tronAddress) throw new Error('Buyer has no refund address on file');
      result.txids.refundTxid = await this._send(deal.buyer.tronAddress, buyerRefund, deal.id, 'REFUND', `split_${sellerBps}bps`);
    }

    // Терминальное состояние по смыслу решения
    const finalState = sellerBps === 0 ? 'REFUNDED' : 'RELEASED';
    this._transition(deal, finalState, `dispute_split_${sellerBps}bps`);
    deal.resolution = {
      sellerBps,
      sellerNet: sellerNet.toString(),
      fee: fee.toString(),
      buyerRefund: buyerRefund.toString(),
    };
    this.ledger.putDeal(deal);

    return {
      deal,
      payout: fromBaseUnits(sellerNet),
      fee: fromBaseUnits(fee),
      refunded: fromBaseUnits(buyerRefund),
      ...result.txids,
    };
  }

  /** Дедлайн прошёл, депозита нет → сделка истекает. Частичный депозит возвращается. */
  async expireIfDue(dealId, now = new Date()) {
    const deal = this._deal(dealId);
    if (deal.state !== 'AWAITING_DEPOSIT') return deal;
    if (now < new Date(deal.deadline)) return deal;

    const deposited = this.ledger.depositedFor(dealId);
    if (deposited > 0n) {
      // Частичный депозит: вернуть покупателю без комиссии — деньги не его вина
      await this._send(deal.buyer.tronAddress, deposited, deal.id, 'REFUND', 'partial_deposit_refund');
    }
    this._transition(deal, 'EXPIRED', 'deadline_passed');
    this.ledger.putDeal(deal);
    return deal;
  }

  async cancel(dealId) {
    const deal = this._deal(dealId);
    this._assertState(deal, ['CREATED', 'AWAITING_DEPOSIT']);
    if (this.ledger.depositedFor(dealId) > 0n) {
      throw new Error('Deal has deposits — use dispute/refund flow, not cancel');
    }
    this._transition(deal, 'CANCELLED', 'cancelled');
    this.ledger.putDeal(deal);
    return deal;
  }

  // ─────────────────────── ВНУТРЕННЕЕ ───────────────────────

  async _payoutToSeller(deal, reason) {
    const deposited = this.ledger.depositedFor(deal.id);
    const s = settlement(deposited, BigInt(deal.amount)); // 1% с продавца + 1% с покупателя

    // Сначала деньги, потом статус: если отправка упала — состояние не испорчено
    const txid = await this._send(deal.seller.tronAddress, s.sellerNet, deal.id, 'PAYOUT', reason);
    this.ledger.append({ dealId: deal.id, type: 'FEE', amount: s.feeTotal, meta: { reason } });

    // Излишек депозита сверх требуемого возвращается покупателю
    if (s.buyerBack > 0n && deal.buyer.tronAddress) {
      await this._send(deal.buyer.tronAddress, s.buyerBack, deal.id, 'REFUND', 'overpayment_refund');
    }

    this._transition(deal, 'RELEASED', reason);
    deal.payout = { txid, amount: s.sellerNet.toString(), fee: s.feeTotal.toString() };
    this.ledger.putDeal(deal);
    return { deal, payout: fromBaseUnits(s.sellerNet), fee: fromBaseUnits(s.feeTotal), txid };
  }

  async _refundToBuyer(deal, reason) {
    const deposited = this.ledger.depositedFor(deal.id);
    if (!deal.buyer.tronAddress) throw new Error('Buyer has no refund address on file');
    const txid = await this._send(deal.buyer.tronAddress, deposited, deal.id, 'REFUND', reason);
    this._transition(deal, 'REFUNDED', reason);
    deal.refund = { txid, amount: deposited.toString() };
    this.ledger.putDeal(deal);
    return { deal, refunded: fromBaseUnits(deposited), txid };
  }

  async _send(toAddress, amount, dealId, entryType, reason) {
    const txid = this.payouts
      ? await this.payouts.sendUSDT(toAddress, amount)
      : `demo_tx_${crypto.randomBytes(8).toString('hex')}`; // в тестах без Tron
    this.ledger.append({ dealId, type: entryType, amount, txid, meta: { to: toAddress, reason } });
    return txid;
  }

  _deal(id) {
    const d = this.ledger.getDeal(id);
    if (!d) throw new Error(`Deal not found: ${id}`);
    return d;
  }

  _assertState(deal, allowed) {
    if (!allowed.includes(deal.state)) {
      throw new Error(`Invalid state: deal is ${deal.state}, expected ${allowed.join('/')}`);
    }
  }

  _transition(deal, to, event) {
    if (!TRANSITIONS[deal.state].includes(to)) {
      throw new Error(`Illegal transition ${deal.state} → ${to}`);
    }
    deal.state = to;
    deal.history.push({ ts: new Date().toISOString(), event, state: to });
  }

  // Отчёт для сверки: сходится ли касса
  reconcile() {
    return {
      totalLockedUnits: this.ledger.totalLocked().toString(),
      totalLocked: fromBaseUnits(this.ledger.totalLocked() < 0n ? 0n : this.ledger.totalLocked()),
      totalFees: fromBaseUnits(this.ledger.totalFees()),
      deals: this.ledger.allDeals().map(d => ({ id: d.id, title: d.title, state: d.state })),
    };
  }
}

module.exports = { EscrowEngine, STATES, TRANSITIONS };
