/**
 * PayMeSafe Escrow Engine — леджер (журнал денег)
 *
 * Принцип: состояние сделки НИКОГДА не меняется напрямую.
 * Каждое движение денег — это запись (entry) в append-only журнале.
 * Балансы всегда вычисляются из журнала, поэтому их нельзя "подправить".
 *
 * Для MVP персистентность — JSON-файл (атомарная запись через rename).
 * Интерфейс совместим с заменой на PostgreSQL: save/load + append.
 */

const fs = require('fs');
const path = require('path');

const ENTRY_TYPES = ['DEPOSIT', 'PAYOUT', 'REFUND', 'FEE', 'ADJUSTMENT'];

class Ledger {
  constructor(filePath) {
    this.filePath = filePath;
    this.deals = new Map();      // dealId -> deal object
    this.entries = [];           // append-only журнал
    this.seenTxids = new Set();  // идемпотентность депозитов
    if (filePath && fs.existsSync(filePath)) this._load();
  }

  /** Идемпотентная запись движения денег */
  append(entry) {
    const { dealId, type, amount, txid } = entry;
    if (!ENTRY_TYPES.includes(type)) throw new Error(`Unknown entry type: ${type}`);
    if (typeof amount !== 'bigint' || amount <= 0n) throw new Error('Amount must be positive BigInt');
    if (txid) {
      if (this.seenTxids.has(txid)) return { duplicate: true }; // уже учли этот tx
      this.seenTxids.add(txid);
    }
    const record = {
      seq: this.entries.length + 1,
      ts: new Date().toISOString(),
      dealId, type, amount: amount.toString(), txid: txid || null,
      meta: entry.meta || {},
    };
    this.entries.push(record);
    this._persist();
    return { duplicate: false, record };
  }

  /** Сколько реально задепонировано по сделке (из журнала, не из поля) */
  depositedFor(dealId) {
    return this.entries
      .filter(e => e.dealId === dealId && e.type === 'DEPOSIT')
      .reduce((sum, e) => sum + BigInt(e.amount), 0n);
  }

  /** Сколько уже выплачено/возвращено по сделке */
  paidOutFor(dealId) {
    return this.entries
      .filter(e => e.dealId === dealId && (e.type === 'PAYOUT' || e.type === 'REFUND'))
      .reduce((sum, e) => sum + BigInt(e.amount), 0n);
  }

  /** Накопленные комиссии платформы */
  totalFees() {
    return this.entries
      .filter(e => e.type === 'FEE')
      .reduce((sum, e) => sum + BigInt(e.amount), 0n);
  }

  /** Сумма, которая прямо сейчас заблокирована в эскроу (инвариант платформы) */
  totalLocked() {
    let locked = 0n;
    for (const e of this.entries) {
      const a = BigInt(e.amount);
      if (e.type === 'DEPOSIT') locked += a;
      if (e.type === 'PAYOUT' || e.type === 'REFUND' || e.type === 'FEE') locked -= a;
    }
    return locked;
  }

  putDeal(deal) { this.deals.set(deal.id, deal); this._persist(); }
  getDeal(id) { return this.deals.get(id); }
  allDeals() { return [...this.deals.values()]; }

  journal(dealId) {
    return dealId ? this.entries.filter(e => e.dealId === dealId) : [...this.entries];
  }

  _persist() {
    if (!this.filePath) return; // режим in-memory для тестов
    const snapshot = JSON.stringify({
      deals: [...this.deals.values()],
      entries: this.entries,
    }, null, 2);
    const tmp = this.filePath + '.tmp';
    fs.writeFileSync(tmp, snapshot);
    fs.renameSync(tmp, this.filePath); // атомарно: файл не может остаться битым
  }

  _load() {
    const raw = JSON.parse(fs.readFileSync(this.filePath, 'utf8'));
    for (const d of raw.deals) this.deals.set(d.id, d);
    this.entries = raw.entries || [];
    for (const e of this.entries) if (e.txid) this.seenTxids.add(e.txid);
  }
}

module.exports = { Ledger, ENTRY_TYPES };
