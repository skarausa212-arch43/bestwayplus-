/**
 * PayMeSafe Escrow Engine — арбитраж
 *
 * Оркестрирует спор поверх движка и чата:
 *   1. Сторона открывает спор → движок морозит выплаты (DISPUTED),
 *      арбитр назначается и получает доступ к чату
 *   2. Обе стороны подают доказательства (постятся в чат как evidence)
 *   3. У сторон есть дедлайн на ответ (по умолчанию 72 часа)
 *   4. Арбитр выносит решение: полное или сплит (напр. 70/30)
 *   5. Движок исполняет решение деньгами, чат получает системную запись
 *
 * Каждое действие оставляет след в чате — это и есть материалы дела.
 */

class ArbitrationService {
  /**
   * @param {EscrowEngine} engine
   * @param {DealChat} chat
   * @param {object} opts
   * @param {string[]} opts.arbiters  email'ы арбитров платформы
   * @param {number} opts.responseHours  дедлайн сторонам на доказательства
   */
  constructor(engine, chat, { arbiters = [], responseHours = 72 } = {}) {
    this.engine = engine;
    this.chat = chat;
    this.arbiters = arbiters;
    this.responseHours = responseHours;
  }

  /** Открыть спор. by — email стороны, которая его открывает. */
  async openCase(dealId, { by, reason }) {
    const deal = this.engine.ledger.getDeal(dealId);
    if (!deal) throw new Error(`Deal not found: ${dealId}`);

    const role = deal.buyer.email === by ? 'buyer'
               : deal.seller.email === by ? 'seller' : null;
    if (!role) throw new Error('Only buyer or seller can open a dispute');
    if (!reason?.trim()) throw new Error('Dispute reason is required');

    await this.engine.openDispute(dealId, { by: role, reason });

    // Назначаем арбитра: наименее загруженный из пула
    const arbiter = this._pickArbiter();
    deal.dispute.arbiter = arbiter;
    deal.dispute.evidenceDeadline = new Date(Date.now() + this.responseHours * 3600_000).toISOString();
    this.engine.ledger.putDeal(deal);

    this.chat.system(dealId,
      `Спор открыт (${role}: «${reason}»). Выплаты заморожены. ` +
      `Арбитр ${arbiter} подключён к чату. ` +
      `Срок подачи доказательств: ${this.responseHours} ч.`,
      { event: 'dispute_opened', arbiter });

    return { deal, arbiter, evidenceDeadline: deal.dispute.evidenceDeadline };
  }

  /** Сторона подаёт доказательства (текст + файлы-хэши) */
  submitEvidence(dealId, { email, text, attachments = [] }) {
    const msg = this.chat.postEvidence(dealId, { email, text, attachments });
    this.chat.system(dealId,
      `${msg.role === 'buyer' ? 'Покупатель' : 'Продавец'} приложил доказательства` +
      (attachments.length ? ` (${attachments.length} файл.)` : ''),
      { event: 'evidence_submitted', messageId: msg.id });
    return msg;
  }

  /** Сообщение арбитра в чат (вопросы сторонам) */
  arbiterMessage(dealId, { arbiter, text }) {
    const deal = this.engine.ledger.getDeal(dealId);
    if (deal?.dispute?.arbiter !== arbiter) throw new Error('Not the assigned arbiter for this case');
    return this.chat.post(dealId, { email: arbiter, text });
  }

  /**
   * Решение арбитра.
   * sellerBps: 10000 = всё продавцу, 0 = всё покупателю, 7000 = 70/30 и т.д.
   * rationale — обоснование, обязательное: решения без мотивировки подрывают доверие.
   */
  async decide(dealId, { arbiter, sellerBps, rationale }) {
    const deal = this.engine.ledger.getDeal(dealId);
    if (!deal) throw new Error(`Deal not found: ${dealId}`);
    if (deal.dispute?.arbiter !== arbiter) throw new Error('Not the assigned arbiter for this case');
    if (!rationale?.trim()) throw new Error('Decision rationale is required');

    deal.dispute.rationale = rationale;
    const result = await this.engine.resolveDisputeSplit(dealId, { sellerBps, arbiter });

    const pct = (sellerBps / 100).toFixed(sellerBps % 100 ? 1 : 0);
    this.chat.system(dealId,
      `Решение арбитра: ${pct}% продавцу / ${(100 - sellerBps / 100).toFixed(sellerBps % 100 ? 1 : 0)}% покупателю. ` +
      `Продавцу выплачено $${result.payout}, возврат покупателю $${result.refunded}, ` +
      `комиссия $${result.fee}. Обоснование: «${rationale}»`,
      { event: 'dispute_resolved', sellerBps });

    return result;
  }

  /** Карточка дела для арбитра: всё в одном месте */
  caseFile(dealId) {
    const deal = this.engine.ledger.getDeal(dealId);
    if (!deal?.dispute) throw new Error('No dispute for this deal');
    return {
      deal: {
        id: deal.id, title: deal.title, amount: deal.amount,
        state: deal.state, feeBps: deal.feeBps,
        buyer: deal.buyer.email, seller: deal.seller.email,
      },
      dispute: deal.dispute,
      moneyTrail: this.engine.ledger.journal(dealId), // полный след денег
      evidence: this.chat.evidence(dealId),
      history: deal.history,
    };
  }

  /** Наименее загруженный арбитр из пула */
  _pickArbiter() {
    if (!this.arbiters.length) throw new Error('No arbiters configured');
    const load = new Map(this.arbiters.map(a => [a, 0]));
    for (const d of this.engine.ledger.allDeals()) {
      if (d.state === 'DISPUTED' && load.has(d.dispute?.arbiter)) {
        load.set(d.dispute.arbiter, load.get(d.dispute.arbiter) + 1);
      }
    }
    return [...load.entries()].sort((a, b) => a[1] - b[1])[0][0];
  }
}

module.exports = { ArbitrationService };
