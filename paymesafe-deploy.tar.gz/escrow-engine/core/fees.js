/**
 * PayMeSafe Escrow Engine — комиссии
 *
 * МОДЕЛЬ: по 1% с каждой стороны сделки.
 *   - Покупатель вносит: сумма сделки + 1% (его комиссия сверху)
 *   - Продавец получает: сумма сделки − 1% (его комиссия из выплаты)
 *   - Платформа зарабатывает 2% с успешной сделки (1% + 1%)
 *   - Если сделка сорвалась/возврат — покупатель получает назад ВСЁ,
 *     включая свой 1%: платформа не зарабатывает на несостоявшихся сделках.
 *   - При сплите спора комиссия берётся только с выпущенной продавцу части.
 *
 * Все суммы — BigInt в базовых единицах USDT (6 знаков). $1 = 1_000_000n.
 */

const USDT_DECIMALS = 6;
const UNIT = 10n ** BigInt(USDT_DECIMALS);

const SIDE_FEE_BPS = 100n; // 1% с каждой стороны

/** "25000" | "25000.50" → базовые единицы */
function toBaseUnits(amountStr) {
  const s = String(amountStr).trim();
  if (!/^\d+(\.\d{1,6})?$/.test(s)) throw new Error(`Invalid USDT amount: "${amountStr}"`);
  const [whole, frac = ''] = s.split('.');
  return BigInt(whole) * UNIT + BigInt(frac.padEnd(USDT_DECIMALS, '0'));
}

function fromBaseUnits(units) {
  const whole = units / UNIT;
  const frac = (units % UNIT).toString().padStart(USDT_DECIMALS, '0').replace(/0+$/, '');
  return frac ? `${whole}.${frac}` : whole.toString();
}

/** 1% от суммы, округление вверх */
function sideFee(units) {
  return (units * SIDE_FEE_BPS + 9999n) / 10000n;
}

/** Сколько покупатель обязан внести: сумма + его 1% */
function requiredDeposit(amountUnits) {
  return amountUnits + sideFee(amountUnits);
}

/**
 * Расчёт исполнения по выпущенной продавцу базе G (при release G = вся сумма,
 * при сплите G = amount × sellerBps / 10000):
 *   sellerNet  = G − 1%G          (продавец)
 *   feeTotal   = 1%G + 1%G        (платформа: сторона продавца + сторона покупателя)
 *   buyerBack  = deposited − sellerNet − feeTotal   (остальное назад покупателю)
 * Инвариант: deposited = sellerNet + feeTotal + buyerBack — всегда.
 */
function settlement(depositedUnits, releasedBaseUnits) {
  const sellerFee = sideFee(releasedBaseUnits);
  const buyerFee = sideFee(releasedBaseUnits);
  const sellerNet = releasedBaseUnits - sellerFee;
  const feeTotal = sellerFee + buyerFee;
  const buyerBack = depositedUnits - sellerNet - feeTotal;
  if (buyerBack < 0n) throw new Error('Settlement underflow: deposit does not cover release');
  return { sellerNet, feeTotal, buyerBack, sellerFee, buyerFee };
}

module.exports = {
  toBaseUnits, fromBaseUnits, sideFee, requiredDeposit, settlement,
  SIDE_FEE_BPS, UNIT, USDT_DECIMALS,
};
