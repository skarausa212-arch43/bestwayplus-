/**
 * PayMeSafe Escrow Engine — комиссии
 *
 * МОДЕЛЬ: по 1% с каждой стороны сделки.
 *   - Покупатель вносит: сумма сделки + 1% (его комиссия сверху)
 *   - Продавец получает: сумма сделки − 1% (его комиссия из выплаты)
 *   - Платформа зарабатывает 2% с успешной сделки (1% + 1%)
 *   - Если сделка сорвалась/возврат — покупатель получает назад ВСЁ,
 *     включая свой 1%: платформа не зарабатывает на несостоявшихся сделках.
 *   - При сплите спора комиссия берётся только с выпущенной продавцу части.
 *
 * Все суммы — BigInt в базовых единицах USDT (6 знаков). $1 = 1_000_000n.
 */

const USDT_DECIMALS = 6;
const UNIT = 10n ** BigInt(USDT_DECIMALS);

const SIDE_FEE_BPS = 100n; // 1% с каждой стороны

/** "25000" | "25000.50" → базовые единицы */
function toBaseUnits(amountStr) {
  const s = String(amountStr).trim();
  if (!/^\d+(\.\d{1,6})?$/.test(s)) throw new Error(`Invalid USDT amount: "${amountStr}"`);
  const [whole, frac = ''] = s.split('.');
  return BigInt(whole) * UNIT + BigInt(frac.padEnd(USDT_DECIMALS, '0'));
}

function fromBaseUnits(units) {
  const whole = units / UNIT;
  const frac = (units % UNIT).toString().padStart(USDT_DECIMALS, '0').replace(/0+$/, '');
  return frac ? `${whole}.${frac}` : whole.toString();
}

/** 1% от суммы, округление вверх */
function sideFee(units) {
  return (units * SIDE_FEE_BPS + 9999n) / 10000n;
}

/** Комиссия bps б.п. от суммы, округление вверх */
function feeOf(units, bps) {
  return (units * BigInt(bps) + 9999n) / 10000n;
}

const TOTAL_FEE_BPS = 200n; // 2% всего с успешной сделки

/**
 * Кто платит комиссию → распределение 2% между сторонами (в б.п.).
 *   'split'  — пополам: покупатель 1% + продавец 1%   (по умолчанию)
 *   'buyer'  — всё платит покупатель: 2% сверх суммы
 *   'seller' — всё платит продавец: 2% из выплаты
 */
function feeSplit(feePayer) {
  if (feePayer === 'buyer')  return { buyerBps: 200, sellerBps: 0 };
  if (feePayer === 'seller') return { buyerBps: 0,   sellerBps: 200 };
  return { buyerBps: 100, sellerBps: 100 }; // split
}

/** Сколько покупатель обязан внести: сумма + его доля комиссии (buyerBps) */
function requiredDeposit(amountUnits, buyerBps = 100) {
  return amountUnits + feeOf(amountUnits, buyerBps);
}

/**
 * Расчёт исполнения по выпущенной продавцу базе G (release: G = вся сумма,
 * сплит спора: G = amount × sellerBps / 10000):
 *   sellerNet  = G − доля продавца (sellerBps)
 *   feeTotal   = доля продавца + доля покупателя  (всегда 2% от G)
 *   buyerBack  = deposited − sellerNet − feeTotal
 * Инвариант: deposited = sellerNet + feeTotal + buyerBack — всегда.
 */
function settlement(depositedUnits, releasedBaseUnits, buyerBps = 100, sellerBps = 100) {
  const sellerFee = feeOf(releasedBaseUnits, sellerBps);
  const buyerFee = feeOf(releasedBaseUnits, buyerBps);
  const sellerNet = releasedBaseUnits - sellerFee;
  const feeTotal = sellerFee + buyerFee;
  const buyerBack = depositedUnits - sellerNet - feeTotal;
  if (buyerBack < 0n) throw new Error('Settlement underflow: deposit does not cover release');
  return { sellerNet, feeTotal, buyerBack, sellerFee, buyerFee };
}

module.exports = {
  toBaseUnits, fromBaseUnits, sideFee, feeOf, feeSplit, requiredDeposit, settlement,
  SIDE_FEE_BPS, TOTAL_FEE_BPS, UNIT, USDT_DECIMALS,
};
