/**
 * PayMeSafe Escrow Engine — чат сделки
 *
 * Правила доступа (это не просто мессенджер, это часть эскроу):
 *   - Писать могут ТОЛЬКО покупатель и продавец этой сделки
 *   - Арбитр получает право писать только когда сделка в DISPUTED
 *   - После терминального состояния (RELEASED/REFUNDED/...) чат read-only
 *   - Системные сообщения пишет сам движок (смена статусов, депозиты)
 *
 * Сообщения append-only: удалить или отредактировать нельзя.
 * В споре переписка — это доказательная база, её целостность критична.
 */

const crypto = require('crypto');

const TERMINAL_STATES = ['RELEASED', 'REFUNDED', 'EXPIRED', 'CANCELLED'];

class DealChat {
  /**
   * @param {Ledger} ledger  чтобы проверять участников и состояние сделки
   * @param {string|null} storePath  JSON-файл (null = in-memory для тестов)
   */
  constructor(ledger, storePath = null) {
    this.ledger = ledger;
    this.storePath = storePath;
    this.messages = new Map(); // dealId -> [messages]
    if (storePath) this._load();
  }

  /** Сообщение от участника сделки */
  post(dealId, { email, text, attachments = [] }) {
    const deal = this._deal(dealId);
    const role = this._roleOf(deal, email);

    if (!role) throw new Error('Only deal participants can post in this chat');
    if (role === 'arbiter' && deal.state !== 'DISPUTED') {
      throw new Error('Arbiter can post only while the deal is disputed');
    }
    if (TERMINAL_STATES.includes(deal.state)) {
      throw new Error(`Chat is read-only: deal is ${deal.state}`);
    }
    if (!text?.trim() && attachments.length === 0) {
      throw new Error('Message must contain text or attachments');
    }

    return this._append(dealId, {
      type: 'text', role, email,
      text: String(text || '').slice(0, 4000), // лимит — защита от мусора
      attachments: attachments.map(a => ({
        name: String(a.name).slice(0, 200),
        // Файл хранится отдельно (S3 и т.п.), в чате — только хэш для целостности
        sha256: a.sha256 || null,
        size: a.size || null,
      })),
    });
  }

  /** Системное сообщение от движка: смена статуса, депозит, решение арбитра */
  system(dealId, text, meta = {}) {
    return this._append(dealId, { type: 'system', role: 'system', email: null, text, meta });
  }

  /** Доказательство в споре — то же сообщение, но помеченное как evidence */
  postEvidence(dealId, { email, text, attachments = [] }) {
    const deal = this._deal(dealId);
    if (deal.state !== 'DISPUTED') throw new Error('Evidence can be submitted only during a dispute');
    const role = this._roleOf(deal, email);
    if (!['buyer', 'seller'].includes(role)) throw new Error('Only buyer or seller can submit evidence');

    const msg = this._append(dealId, {
      type: 'evidence', role, email,
      text: String(text || '').slice(0, 4000),
      attachments: attachments.map(a => ({ name: a.name, sha256: a.sha256 || null, size: a.size || null })),
    });
    return msg;
  }

  /** История чата. Видна только участникам (и арбитру после открытия спора). */
  history(dealId, viewerEmail) {
    const deal = this._deal(dealId);
    const role = this._roleOf(deal, viewerEmail);
    if (!role) throw new Error('Only deal participants can read this chat');
    return this.messages.get(dealId) || [];
  }

  /** Только доказательства — для карточки арбитра */
  evidence(dealId) {
    return (this.messages.get(dealId) || []).filter(m => m.type === 'evidence');
  }

  _roleOf(deal, email) {
    if (!email) return null;
    if (deal.buyer.email === email) return 'buyer';
    if (deal.seller.email === email) return 'seller';
    if (deal.dispute?.arbiter === email) return 'arbiter';
    return null;
  }

  _append(dealId, body) {
    const msg = {
      id: crypto.randomUUID(),
      ts: new Date().toISOString(),
      dealId,
      ...body,
    };
    if (!this.messages.has(dealId)) this.messages.set(dealId, []);
    this.messages.get(dealId).push(msg);
    this._persist();
    return msg;
  }

  _deal(id) {
    const d = this.ledger.getDeal(id);
    if (!d) throw new Error(`Deal not found: ${id}`);
    return d;
  }

  _persist() {
    if (!this.storePath) return;
    const fs = require('fs');
    const tmp = this.storePath + '.tmp';
    fs.writeFileSync(tmp, JSON.stringify([...this.messages.entries()], null, 2));
    fs.renameSync(tmp, this.storePath);
  }

  _load() {
    const fs = require('fs');
    if (!fs.existsSync(this.storePath)) return;
    for (const [k, v] of JSON.parse(fs.readFileSync(this.storePath, 'utf8'))) {
      this.messages.set(k, v);
    }
  }
}

module.exports = { DealChat };
