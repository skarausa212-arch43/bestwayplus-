/**
 * Тесты чата сделки и арбитража. Запуск: node test-arbitration.js
 */

const assert = require('assert');
const { EscrowEngine } = require('./core/escrow-engine');
const { DealChat } = require('./core/chat');
const { ArbitrationService } = require('./core/arbitration');
const { toBaseUnits, fromBaseUnits } = require('./core/fees');

let passed = 0, failed = 0;
async function test(name, fn) {
  try { await fn(); console.log(`  ✅ ${name}`); passed++; }
  catch (e) { console.log(`  ❌ ${name}\n     → ${e.message}`); failed++; }
}

const buyer = { email: 'buyer@test.com', tronAddress: 'TBuyerAddr' };
const seller = { email: 'seller@test.com', tronAddress: 'TSellerAddr' };
const ARBITERS = ['arb1@paymesafe.online', 'arb2@paymesafe.online'];

(async () => {
  const engine = new EscrowEngine();
  const chat = new DealChat(engine.ledger);
  const arb = new ArbitrationService(engine, chat, { arbiters: ARBITERS });

  // Готовим FUNDED-сделку на $10,000 (ставка 2.0%)
  const deal = await engine.createDeal({ title: 'Оборудование из Китая', amount: '10000', buyer, seller });
  await engine.approve(deal.id, 'buyer');
  await engine.approve(deal.id, 'seller');
  await engine.onDepositConfirmed(deal.id, { amount: toBaseUnits('10100'), txid: 'tx_arb_1', from: 'TB' }); // 10000 + 1%

  console.log('\n══════ 1. ЧАТ: ПРАВА ДОСТУПА ══════');

  await test('покупатель и продавец могут писать', () => {
    chat.post(deal.id, { email: buyer.email, text: 'Когда отгрузка?' });
    chat.post(deal.id, { email: seller.email, text: 'Завтра, трек пришлю сюда' });
    assert.equal(chat.history(deal.id, buyer.email).length, 2);
  });

  await test('посторонний писать НЕ может', () => {
    assert.throws(() => chat.post(deal.id, { email: 'hacker@evil.com', text: 'hi' }), /participants/);
  });

  await test('посторонний читать НЕ может', () => {
    assert.throws(() => chat.history(deal.id, 'hacker@evil.com'), /participants/);
  });

  await test('арбитр НЕ может писать до открытия спора', () => {
    assert.throws(() => chat.post(deal.id, { email: ARBITERS[0], text: 'я тут' }), /participants|disputed/i);
  });

  await test('пустое сообщение отклоняется', () => {
    assert.throws(() => chat.post(deal.id, { email: buyer.email, text: '   ' }), /must contain/);
  });

  await test('evidence нельзя подать вне спора', () => {
    assert.throws(() => chat.postEvidence(deal.id, { email: buyer.email, text: 'фото' }), /during a dispute/);
  });

  console.log('\n══════ 2. ОТКРЫТИЕ СПОРА ══════');

  let assignedArbiter;
  await test('покупатель открывает спор → DISPUTED + арбитр + дедлайн', async () => {
    const r = await arb.openCase(deal.id, { by: buyer.email, reason: 'Станок пришёл с трещиной в станине' });
    assignedArbiter = r.arbiter;
    assert.equal(engine.ledger.getDeal(deal.id).state, 'DISPUTED');
    assert.ok(ARBITERS.includes(assignedArbiter));
    assert.ok(r.evidenceDeadline);
  });

  await test('в чате появилась системная запись об открытии спора', () => {
    const sys = chat.history(deal.id, buyer.email).filter(m => m.type === 'system');
    assert.ok(sys.some(m => m.text.includes('Спор открыт')));
  });

  await test('посторонний НЕ может открыть спор', async () => {
    const d2 = await engine.createDeal({ title: 'x', amount: '100', buyer, seller });
    await engine.approve(d2.id, 'buyer');
    await engine.approve(d2.id, 'seller');
    await engine.onDepositConfirmed(d2.id, { amount: toBaseUnits('101'), txid: 'tx_arb_2', from: 'TB' });
    await assert.rejects(() => arb.openCase(d2.id, { by: 'evil@x.com', reason: 'дай деньги' }), /Only buyer or seller/);
    await engine.release(d2.id, 'buyer'); // закрываем, чтобы касса сошлась
  });

  console.log('\n══════ 3. ДОКАЗАТЕЛЬСТВА И ЧАТ В СПОРЕ ══════');

  await test('обе стороны подают доказательства с файлами', () => {
    arb.submitEvidence(deal.id, {
      email: buyer.email, text: 'Фото трещины при вскрытии',
      attachments: [{ name: 'crack_photo.jpg', sha256: 'a1b2c3', size: 2048_000 }],
    });
    arb.submitEvidence(deal.id, {
      email: seller.email, text: 'Акт погрузки без повреждений + видео упаковки',
      attachments: [{ name: 'loading_act.pdf', sha256: 'd4e5f6', size: 512_000 }],
    });
    assert.equal(chat.evidence(deal.id).length, 2);
  });

  await test('арбитр теперь может писать в чат', () => {
    const msg = arb.arbiterMessage(deal.id, {
      arbiter: assignedArbiter,
      text: 'Прошу покупателя приложить фото маркировки на упаковке',
    });
    assert.equal(msg.role, 'arbiter');
  });

  await test('чужой арбитр вести дело НЕ может', () => {
    const other = ARBITERS.find(a => a !== assignedArbiter);
    assert.throws(() => arb.arbiterMessage(deal.id, { arbiter: other, text: 'я решу' }), /Not the assigned/);
  });

  console.log('\n══════ 4. РЕШЕНИЕ: СПЛИТ 70/30 ══════');

  await test('решение без обоснования отклоняется', async () => {
    await assert.rejects(
      () => arb.decide(deal.id, { arbiter: assignedArbiter, sellerBps: 7000, rationale: '' }),
      /rationale is required/);
  });

  await test('сплит 70/30: продавцу $6,930, платформе $140, возврат $3,030', async () => {
    // Депозит $10,100 (10000 + 1%). Выпущено продавцу 70% = $7,000:
    //   продавцу 7000 − 1% = $6,930; платформе 70+70 = $140
    //   покупателю назад 10100 − 6930 − 140 = $3,030 (его доля + его 1% с неё)
    const r = await arb.decide(deal.id, {
      arbiter: assignedArbiter, sellerBps: 7000,
      rationale: 'Повреждение подтверждено, но частично работоспособно: транспортный риск делится',
    });
    assert.equal(r.payout, '6930');
    assert.equal(r.fee, '140');
    assert.equal(r.refunded, '3030');
    assert.equal(r.deal.state, 'RELEASED');
  });

  await test('решение записано в чат системным сообщением', () => {
    const sys = chat.history(deal.id, seller.email).filter(m => m.type === 'system');
    assert.ok(sys.some(m => m.text.includes('Решение арбитра: 70%')));
  });

  await test('после решения чат read-only', () => {
    assert.throws(() => chat.post(deal.id, { email: buyer.email, text: 'ещё вопрос' }), /read-only/);
  });

  await test('повторно решить дело нельзя', async () => {
    await assert.rejects(
      () => arb.decide(deal.id, { arbiter: assignedArbiter, sellerBps: 0, rationale: 'передумал' }),
      /Invalid state/);
  });

  console.log('\n══════ 5. КАРТОЧКА ДЕЛА И КАССА ══════');

  await test('caseFile собирает всё: деньги, доказательства, историю', () => {
    const cf = arb.caseFile(deal.id);
    assert.equal(cf.evidence.length, 2);
    assert.ok(cf.moneyTrail.length >= 3); // депозит + выплата + комиссия + возврат
    assert.equal(cf.dispute.sellerBps, 7000);
    assert.ok(cf.dispute.rationale);
  });

  await test('касса сходится после сплита: locked = 0', () => {
    assert.equal(engine.ledger.totalLocked().toString(), '0');
    console.log(`     Комиссии платформы за сессию: $${fromBaseUnits(engine.ledger.totalFees())}`);
  });

  console.log(`\n${'═'.repeat(50)}`);
  console.log(`ИТОГО: ${passed} passed, ${failed} failed`);
  process.exit(failed ? 1 : 0);
})();
